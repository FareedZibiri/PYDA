## Python for Data Analytics: First Steps into Programming

#### This Project is done and presented by Fareed Zibiri


### Task
Design a Chess Game using Python


### Links

[Jupyter Notebook Link](http://localhost:8889/lab/tree/Downloads/Turing%20College/Module%204%20-%20Python/Chess%20Game.ipynb)
